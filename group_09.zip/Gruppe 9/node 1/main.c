/*
 * ice_ice.c
 *
 * Created: 26.08.2020 14:28:49
 * Author : magneah
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include "DEFINITIONS.h"
#include <util/delay.h>
#include "USART.h"
#include <stdio.h>
#include <string.h>
#include "joystick_driver.h"
#include "OLED_driver.h"
#include "mcp2515_driver.h"
#include "can_driver.h"
#include "menu.h"

int main(void){
	USART_Init ( MYUBRR );
	//enable external memory interface
	MCUCR |= (1<<SRE);
	
	//select which c pins on atmega to be released for normal use, the rest is used for high address bytes
	SFIOR &= ~(1<<XMM0);
	SFIOR &= ~(1<<XMM1);
	SFIOR |= (1<<XMM2);
	DDRA |= 0x18;
	
	can_init();
	
	can_interrupt_enable();
	launch_menusystem();
	
	while(1){
		//Send joystick to node 2 even if the menu fails
		send_stick_can();
		_delay_ms(50);
		printf("menu fail");
	}
	
	return 0;
}

