/*
 * GccApplication1.c
 *
 * Created: 07.10.2020 08:47:43
 * Author : bendil
 */ 


#include "sam.h"
#include "can_controller.h"
#include "uart.h"
#include "printf-stdarg.h"
#include "timer_driver.h"
#include "adc_controller.h"
#include "adc_interrupt.h"
#include "dac_controller.h"
#include "motor_controller.h"
#include "timer.h"
#include "feedback.h"
#include "pid.h"

int main(void)
{
    /* Initialize the SAM system */
    SystemInit();
	WDT->WDT_MR |= 1 << 15;
	configure_uart();
	can_init_def_tx_rx_mb(0x00290561); // 0x00290561 = 0b 00000000001010010000010101100001// 0b000000000000100100010001000100010
	
	timer_init();
	timer_change_duty(100);
	init_ch1_PI();
	adc_init();
	dac_init();
	motor_box_init();
	SysTick_init();
	
	
	//enable and set high, pin to controll servo shoot, pin50 on shield
	PIOC->PIO_PER |= PIO_PER_P13; 
	PIOC->PIO_OER |= PIO_OER_P13; 
	PIOC->PIO_SODR |= PIO_SODR_P13;
	
	PIOA->PIO_PER |= PIO_PER_P19; //PIO Enable Register, PIO Enable
	PIOA->PIO_OER |= PIO_OER_P19; //Output Enable Register, Output Enable
	
	PIOA->PIO_PER |= PIO_PER_P20; //PIO Enable Register, PIO Enable
	PIOA->PIO_OER |= PIO_OER_P20; //Output Enable Register, Output Enable
	
	volatile CAN_MESSAGE msg;
	CAN_MESSAGE msgToSend;
	uint8_t solenoide_pressed = 0;
    while (1) 
    {
		//Beautiful blinking LED lights 
		PIOA->PIO_SODR = PIO_SODR_P19; //Set Output Data Register, Set Output Data
		for(int i = 0; i < 1600000; i++){
		}
		PIOA->PIO_CODR = PIO_CODR_P19; //Clear Output Data Register, Set Output Data
		PIOA->PIO_SODR = PIO_SODR_P20; //Set Output Data Register, Set Output Data
		for(int i = 0; i < 1600000; i++){
		}
		PIOA->PIO_CODR |= PIO_CODR_P20; //Clear Output Data Register,
		
		
		move_servo();
		encoder_read();
		check_solenoid_shot();
	
		//Send time back to node 1
		send_time_to_node_1(&msgToSend);

		//Send motor status back to node 1
		//limits to fewer OLED updates a second, can be tweaked
		if(!(get_controller_runs()%3)){
			send_motor_info_to_node_1(&msgToSend, get_pi_value(), get_solenoid_status());
			//Make sure 8 bit does not overflow as it would break logic
			if(get_controller_runs > 250){
				reset_controller_runs();
			}
		}
		
		//Send goal info back to node 1
		if(get_goal_flag()){
			send_goal_to_node_1(&msgToSend);
			reset_goal_flag();
		}
    }
}
